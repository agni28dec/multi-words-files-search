package com.catlin.pizza.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.catlin.pizza.builder.PizzaBuilder;
import com.catlin.pizza.enums.Crust;
import com.catlin.pizza.enums.NonVegTopping;
import com.catlin.pizza.enums.Size;
import com.catlin.pizza.enums.VegTopping;
import com.catlin.pizza.model.Pizza;

public class PizzaBuilderTest {

	@Test
	public void testBuildThickCrustMediumPizzaWithOneVegAndOneNonVegTopping(){

		Pizza pizza = new PizzaBuilder().withCrust(Crust.THICK).withToppings(VegTopping.VEGGIEMEDIUM,NonVegTopping.NONVEGGIEMEDIUM).withSize(Size.MEDIUM).build();
		assertEquals(VegTopping.VEGGIEMEDIUM,pizza.getVegTopping());
		assertEquals(NonVegTopping.NONVEGGIEMEDIUM,pizza.getNonVegTopping());
		assertEquals(Size.MEDIUM,pizza.getSize());
		assertEquals(Crust.THICK,pizza.getCrust());
		assertEquals(412.00,pizza.getTotalPrice(),0);
		System.out.print(pizza.getTotalPrice());
	}
}
