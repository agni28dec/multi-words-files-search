package com.catlin.pizza.enums;

public enum Size {

	SMALL {
		public double getCost() {
			return 150.00;
		}
	},MEDIUM {
		public double getCost() {
			return 250.50;
		}
	},LARGE {
		public double getCost() {
			return 400.00;
		}
	}, PARTY {
		public double getCost() {
			return 600.00;
		}
	};

	public abstract double getCost();
}
