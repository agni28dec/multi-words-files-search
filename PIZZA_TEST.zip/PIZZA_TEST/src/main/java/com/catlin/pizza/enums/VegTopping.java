package com.catlin.pizza.enums;

public enum VegTopping {

	VEGGIESMALL {
		public double getCost(){
			return 35.50;
		}
	}, VEGGIEMEDIUM{
		public double getCost(){
			return 50.50;
		}
	}, VEGGIELARGE{
		public double getCost(){
			return 75.50;
		}
	},VEGGIEPARTY{
		public double getCost(){
			return 100.00;
		}
	};
	public abstract double getCost();
}