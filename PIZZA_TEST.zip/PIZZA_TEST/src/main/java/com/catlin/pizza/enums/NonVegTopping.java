package com.catlin.pizza.enums;

public enum NonVegTopping {

	NONVEGGIESMALL {
		public double getCost(){
			return 50.50;
		}
	}, NONVEGGIEMEDIUM{
		public double getCost(){
			return 75.50;
		}
	}, NONVEGGIELARGE{
		public double getCost(){
			return 100.00;
		}
	},NONVEGGIEPARTY{
		public double getCost(){
			return 125.00;
		}
	};
	public abstract double getCost();
}