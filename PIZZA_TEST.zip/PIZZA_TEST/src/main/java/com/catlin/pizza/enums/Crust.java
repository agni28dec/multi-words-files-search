package com.catlin.pizza.enums;

public enum Crust {

	THIN  {
		public double getCost(){
			return 0.00;
		}
	} , THICK{
		public double getCost(){
			return 35.50;
		}
	};

	public abstract double getCost();
}
