package com.catlin.pizza.model;

import com.catlin.pizza.enums.Crust;
import com.catlin.pizza.enums.Size;
import com.catlin.pizza.enums.VegTopping;
import com.catlin.pizza.enums.NonVegTopping;

public class Pizza {

	private double totalPrice = 0;

	private Size size;
	private VegTopping vegTopping;
	private NonVegTopping nonVegTopping;
	private Crust crust;

	public Size getSize() {
		return size;
	}

	public void setSize(Size size) {
		this.size = size;
	}

	public VegTopping getVegTopping() {
		return vegTopping;
	}

	public void setVegTopping(VegTopping vegTopping) {
		this.vegTopping = vegTopping;
	}

	public NonVegTopping getNonVegTopping() {
		return nonVegTopping;
	}

	public void setNonVegTopping(NonVegTopping nonVegTopping) {
		this.nonVegTopping = nonVegTopping;
	}

	public Crust getCrust() {
		return crust;
	}

	public void setCrust(Crust crust) {
		this.crust = crust;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void addToPrice(double price) {
		this.totalPrice = totalPrice + price;
	}
}
