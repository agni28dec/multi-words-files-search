package com.catlin.pizza.builder;

import com.catlin.pizza.enums.Crust;
import com.catlin.pizza.enums.NonVegTopping;
import com.catlin.pizza.enums.Size;
import com.catlin.pizza.enums.VegTopping;
import com.catlin.pizza.model.Pizza;

public class PizzaBuilder {

	Pizza pizza = new Pizza();

	public PizzaBuilder withToppings(VegTopping vegTopping,NonVegTopping nonVegTopping) {
		pizza.setVegTopping(vegTopping);
		pizza.addToPrice(vegTopping.getCost());
		pizza.setNonVegTopping(nonVegTopping);
		pizza.addToPrice(nonVegTopping.getCost());
		return this;
	}

	public PizzaBuilder withSize(Size size) {
		pizza.setSize(size);
		pizza.addToPrice(size.getCost());
		return this;
	}

	public PizzaBuilder withCrust(Crust crust) {
		pizza.setCrust(crust);
		pizza.addToPrice(crust.getCost());
		return this;
	}

	public Pizza build() {
		return pizza;
	}

	public double calculatePrice() {
		return pizza.getTotalPrice();
	}

}