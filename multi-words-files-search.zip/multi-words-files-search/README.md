This project search a configured file system for files which contains all the words passed by users.
Fuzzy search is not being implemented instead whole word search has been taken care of.
Project has been implemented using REST API , Spring Boot , Java NIO and Java Streams etc APIs.

Thanks,
Himanshu Agnihotri